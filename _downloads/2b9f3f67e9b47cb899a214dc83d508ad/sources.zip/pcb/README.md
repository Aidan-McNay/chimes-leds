# pcb

A collection of the PCB files for:

 - The control panel
 - The sensor board
 - A clock face board

All of these were created with KiCad